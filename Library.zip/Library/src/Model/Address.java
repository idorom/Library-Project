package Model;

public class Address {

}
