package Utils;

public enum PaperValue {
	WORK_SHOP,CONFERENCE,MAGAZINE

}
