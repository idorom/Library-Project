package Utils;

public enum BookSize {
	SMALL,AVERAGE,BIG

}
