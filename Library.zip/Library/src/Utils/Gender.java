package Utils;

public enum Gender {
		Male,Female
}