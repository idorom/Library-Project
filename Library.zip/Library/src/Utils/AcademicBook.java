package Utils;

public enum AcademicBook {
	ACADEMIC,NON_ACADEMIC

}
