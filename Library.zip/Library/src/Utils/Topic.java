package Utils;

public enum Topic {
	HISTORY,CS,MATH,BIOLOGY,CHEMISTRY,PHYSICS,SOCIOLOGY

}
