package Utils;

public enum UserType {
	UNKNOWN ,ADMIN, LIBRARIAN, READER
}
